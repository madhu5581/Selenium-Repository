package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.ProjectWrappers;

public class ViewLeadPage extends ProjectWrappers {	
	
	public ViewLeadPage(RemoteWebDriver driver, ExtentTest test) {
		this.driver = driver;
		this.test = test;
		if(!verifyTitle("View Lead | opentaps CRM")) {
			reportStep("This is not View Lead Page", "Fail");
		}		
	}
	
	public ViewLeadPage verifyFirstName(String data){
		verifyTextById("viewLead_firstName_sp", data);
		return this;
	}
	
	
	
	
	
	
	
}










