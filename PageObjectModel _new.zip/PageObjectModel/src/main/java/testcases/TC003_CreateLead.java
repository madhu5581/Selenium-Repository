package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.LoginPage;
import wrappers.ProjectWrappers;

public class TC003_CreateLead extends ProjectWrappers {
	@BeforeClass
	public void setData() {
		testCaseName = "createLead";
		testDescription = "Create the Lead";
		authors = "Bala";
		category = "Sanity";
		dataSheetName = "TC003";
		browserName = "chrome";
	}
	
	@Test(dataProvider = "fetchData")
	public void leadCreate(String uName,String pwd,String cName, String fName, String lName) {
		
		new LoginPage(driver, test)
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
	    .clickCRMSFA()
	    .clickLeads()
	    .clickCreateLeadLink()
	    .enterCompanyName(cName)
	    .enterFirstName(fName)
		.enterLastName(lName)
		.clickCreateLeadButton()
		.verifyFirstName(fName);
	
		
		
	}

}
