package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.LoginPage;
import wrappers.ProjectWrappers;

public class TC004_EditLead extends ProjectWrappers{
	@BeforeClass
	public void setData() {
		testCaseName = "editLead";
		testDescription = "Edit the Lead";
		authors = "Bala";
		category = "Smoke";
		dataSheetName = "TC004";
		browserName = "chrome";
	}
	
	@Test(dataProvider = "fetchData")
	public void EditLead(String uName,String pwd,String cName, String fName) {
		
		new LoginPage(driver, test)
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
	    .clickCRMSFA()
	    .clickLeads()
	    .clickFindLeadsLink()
	    .enterFirstName(fName)
	    .clickFindLeadsButton()
	    .clickFirstResultLeadLink()
	    .clickEditButton()
	    .changeCompanyName(cName)
	    .clickUpdateButton()
	    .verifyCompanyName(cName);
	    
	

}
}