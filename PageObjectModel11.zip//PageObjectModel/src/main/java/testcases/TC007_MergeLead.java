package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.LoginPage;
import wrappers.ProjectWrappers;

public class TC007_MergeLead extends ProjectWrappers{
	@BeforeClass
	public void setData() {
		testCaseName = "mergeLead";
		testDescription = "Merge the Lead";
		authors = "Bala";
		category = "Sanity";
		dataSheetName = "TC007";
		browserName = "chrome";
	}
	
	@Test(dataProvider = "fetchData")
	public void EditLead(String uName,String pwd,String LeadId1,String LeadId2) {
		
		new LoginPage(driver, test)
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
	    .clickCRMSFA()
	    .clickLeads()
	    .clickMergeLeadsLink()
	    .clickFromIconLead()
	    .enterLeadId(LeadId1)
	    .clickFindLeadsButton()
	    .clickFirstLeadId()
	    .clickToIconLead()
	    .enterLeadId(LeadId2)
	    .clickFindLeadsButton()
	    .clickFirstLeadId()
		.clickMergeButton()
		.acceptOk()	
	    .clickFindLeadspage()
		.enterByLeadId(LeadId1)
		.clickFindLeadsButton()
		.verifyErrorMessage();
	}	
}