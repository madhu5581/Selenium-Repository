package testcases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

public class testrun {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RemoteWebDriver driver;	
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("http://leaftaps.com/opentaps");	
		driver.findElementById("username").sendKeys("DemoSalesManager");
		//provide the password
		driver.findElementById("password").sendKeys("crmsfa");
		//Click on Submit
		driver.findElementByClassName("decorativeSubmit").click();

	}

}
