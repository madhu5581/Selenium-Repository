package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.LoginPage;
import wrappers.ProjectWrappers;

public class TC006_DeleteLead extends ProjectWrappers{
	@BeforeClass
	public void setData() {
		testCaseName = "deleteLead";
		testDescription = "Delete the Lead";
		authors = "Bala";
		category = "Sanity";
		dataSheetName = "TC006";
		browserName = "chrome";
	}
	
	@Test(dataProvider = "fetchData")
	public void EditLead(String uName,String pwd,String phoneno) {
		
		new LoginPage(driver, test)
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
	    .clickCRMSFA()
	    .clickLeads()
	    .clickFindLeadsLink()
	    .clickPhoneTab()
	    .enterPhoneNum(phoneno)
	    .clickFindLeadsButton()
	    .captureLeadId()
	    .clickFirstLeadId()
	    .clickDeleteButton()
	    .clickFindLeadsLink()
	    .enterCapturedLeadId()
	    .clickFindLeadsButton()
	    .verifyErrorMessage();
	    
	

}
}