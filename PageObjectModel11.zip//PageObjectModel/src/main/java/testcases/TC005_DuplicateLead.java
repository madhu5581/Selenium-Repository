package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.LoginPage;
import wrappers.ProjectWrappers;

public class TC005_DuplicateLead extends ProjectWrappers{
	@BeforeClass
	public void setData() {
		testCaseName = "duplicateLead";
		testDescription = "Duplicate the Lead";
		authors = "Bala";
		category = "Sanity";
		dataSheetName = "TC005";
		browserName = "chrome";
	}
	
	@Test(dataProvider = "fetchData")
	public void EditLead(String uName,String pwd,String emailId, String postCode) {
		
		new LoginPage(driver, test)
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
	    .clickCRMSFA()
	    .clickLeads()
	    .clickFindLeadsLink()
	    .clickEmailTab()
	    .enterEmailId(emailId)
	    .clickFindLeadsButton()
	    .captureName()
	    .clickFirstLeadId()
	    .clickDuplicateButton()
	    .enterPostCode(postCode)
	    .clickCreateLeadButton()
		.verifyDuplicateLeadName();
	

}
}