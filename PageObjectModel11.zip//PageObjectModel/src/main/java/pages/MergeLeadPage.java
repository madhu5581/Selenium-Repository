package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.ProjectWrappers;

public class MergeLeadPage extends ProjectWrappers 
{
	
	public MergeLeadPage(RemoteWebDriver driver,ExtentTest test){
		this.driver=driver;
		this.test=test;
	
		if(!verifyTitle("Merge Leads | opentaps CRM")){
			reportStep("This is not Find Leads Page", "Fail");
		}
	}
	public MergeLeadPage enterFirstName(String data)
	{
		enterByXpath("(//input[@name='firstName'])[3]", data);
		return this;
		
	}
	public MergeLeadPage clickFindLeadsButton()
	{
		clickByXpath("//button[contains(text(),'Find Leads')]");
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}
	public ViewLeadPage clickFirstResultLeadLink()
	{
		clickByXpath("(//div[contains(@class,'x-grid3')]/a[@class='linktext'])[1]");
		return new ViewLeadPage(driver, test);
	}
	public MergeLeadPage clickEmailTab()
	{
		clickByXpath("(//span[@class='x-tab-strip-inner'])[3]");
		return this;
	}

	public MergeLeadPage clickPhoneTab()
	{
		clickByXpath("(//span[@class='x-tab-strip-text '])[2]");
		return this;
	}
	
	
	public MergeLeadPage enterEmailId(String data)
	{
		enterByXpath("//input[@name='emailAddress']", data);
		return this;
	}
	
	

	public MergeLeadPage enterPhoneNum(String data)
	{
		enterByName("phoneNumber", data);
		return this;
	}
	
	public MergeLeadPage captureName()
	{
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 captureText =getTextByXpath("(//div[contains(@class,'x-grid3')]/a[@class='linktext'])[3]");
		
		 return this;
		
	}
	
	public MergeLeadPage captureLeadId()
	{
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		captureLdId =getTextByXpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");
		System.out.println("hello "+captureLdId);
		 return this;
		
	}
	
	public ViewLeadPage clickFirstLeadId()
	{
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		clickByXpath("(//div[contains(@class,'x-grid3')]/a[@class='linktext'])[1]");
		return new ViewLeadPage(driver,test);
	}
	
	public MergeLeadPage enterCapturedLeadId()
	{
		enterByName("id", captureLdId);
		return this;
	}
	
	public MergeLeadPage verifyErrorMessage()
	{
	  verifyTextByXpath("//div[@class='x-paging-info']", errMsg);
	  return this;
	}
	
	public FindLeadsChildPage clickFromIconLead()
	{
		
		//Set<String> allWindows=driver.getWindowHandles();
		clickByXpathNoSnap("(//img[contains(@alt,'Lookup')])[1]");
		switchToLastWindow();
		/*for(String eachwindow:allWindows)
		{
			driver.switchTo().window(eachwindow);
		}*/
		return new FindLeadsChildPage(driver,test);
	}
	
	public FindLeadsChildPage clickToIconLead()
	{	
		
		//Set<String> allWindows=driver.getWindowHandles();
		clickByXpath("(//img[contains(@alt,'Lookup')])[2]");
		switchToLastWindow();
		/*for(String eachwindow:allWindows)
		{
			driver.switchTo().window(eachwindow);
		}*/
		return new FindLeadsChildPage(driver,test); 
	}
	
	public MergeLeadPage clickMergeButton()
	{
		clickByLinkNoSnap("Merge");
		return this;
	}
	
	public ViewLeadPage acceptOk()
	{
		acceptAlert();
		return new ViewLeadPage(driver, test);
	}
}
