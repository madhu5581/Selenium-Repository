package pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.ProjectWrappers;

public class FindLeadsPage extends ProjectWrappers 
{
	
	public FindLeadsPage(RemoteWebDriver driver,ExtentTest test){
		this.driver=driver;
		this.test=test;
	
		if(!verifyTitle("Find Leads | opentaps CRM")){
			reportStep("This is not Find Leads Page", "Fail");
		}
	}
	public FindLeadsPage enterFirstName(String data)
	{
		enterByXpath("(//input[@name='firstName'])[3]", data);
		return this;
		
	}
	public FindLeadsPage clickFindLeadsButton()
	{
		clickByXpath("//button[contains(text(),'Find Leads')]");
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}
	public ViewLeadPage clickFirstResultLeadLink()
	{
		clickByXpath("(//div[contains(@class,'x-grid3')]/a[@class='linktext'])[1]");
		return new ViewLeadPage(driver, test);
	}
	public FindLeadsPage clickEmailTab()
	{
		clickByXpath("(//span[@class='x-tab-strip-inner'])[3]");
		return this;
	}

	public FindLeadsPage clickPhoneTab()
	{
		clickByXpath("(//span[@class='x-tab-strip-text '])[2]");
		return this;
	}
	
	
	public FindLeadsPage enterEmailId(String data)
	{
		enterByXpath("//input[@name='emailAddress']", data);
		return this;
	}
	
	

	public FindLeadsPage enterPhoneNum(String data)
	{
		enterByName("phoneNumber", data);
		return this;
	}
	
	public FindLeadsPage captureName()
	{
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 captureText =getTextByXpath("(//div[contains(@class,'x-grid3')]/a[@class='linktext'])[3]");
		
		 return this;
		
	}
	
	public FindLeadsPage captureLeadId()
	{
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		captureLdId =getTextByXpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");
		System.out.println("hello "+captureLdId);
		 return this;
		
	}
	
	public ViewLeadPage clickFirstLeadId()
	{
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		clickByXpath("(//div[contains(@class,'x-grid3')]/a[@class='linktext'])[1]");
		return new ViewLeadPage(driver,test);
	}
	
	public FindLeadsPage enterCapturedLeadId()
	{
		enterByName("id", captureLdId);
		return this;
	}
	
	public FindLeadsPage verifyErrorMessage()
	{
	  verifyTextByXpath("//div[@class='x-paging-info']", errMsg);
	  return this;
	}
	
	public FindLeadsPage enterByLeadId(String data)
	{
		enterByName("id", data);
		return this;
	}
	public MergeLeadPage enterLeadId(String leadId1) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}
