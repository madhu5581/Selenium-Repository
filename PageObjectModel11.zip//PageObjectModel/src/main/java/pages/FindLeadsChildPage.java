package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.ProjectWrappers;

public class FindLeadsChildPage extends ProjectWrappers 
{
	
	public FindLeadsChildPage(RemoteWebDriver driver,ExtentTest test){
		this.driver=driver;
		this.test=test;
	
		/*if(!verifyTitle("Find Leads")){
			reportStep("This is not Find Leads Child Page", "Fail");
		}*/
	}
	public FindLeadsChildPage enterLeadId(String data)
	{
		enterByName("id", data);
		//enterByXpath("(//input[@name='firstName'])[3]", data);
		return this;
		
	}
	public FindLeadsChildPage clickFindLeadsButton()
	{
		clickByXpath("//button[contains(text(),'Find Leads')]");
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}
	
	public FindLeadsChildPage captureLeadId()
	{
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		captureLdId =getTextByXpath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");
		System.out.println("hello "+captureLdId);
		 return this;
		
	}
	
	public MergeLeadPage clickFirstLeadId()
	{
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		clickByXpathNoSnap("(//div[contains(@class,'x-grid3')]/a[@class='linktext'])[1]");
		switchToParentWindow();
		return new MergeLeadPage(driver,test);
	}
	
	public FindLeadsChildPage enterCapturedLeadId()
	{
		enterByName("id", captureLdId);
		return this;
	}
	
	public FindLeadsChildPage verifyErrorMessage()
	{
	  verifyTextByXpath("//div[@class='x-paging-info']", errMsg);
	  return this;
	}
	
}
