package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentTest;

import wrappers.ProjectWrappers;

public class ViewLeadPage extends ProjectWrappers {	
	
	public ViewLeadPage(RemoteWebDriver driver, ExtentTest test) {
		this.driver = driver;
		this.test = test;
		if(!verifyTitle("View Lead | opentaps CRM")) {
			reportStep("This is not View Lead Page", "Fail");
		}		
	}
	public EditLeadPage clickEditButton()
	{
		clickByXpath("//a[@class='subMenuButton' and text()='Edit']");
		return new EditLeadPage(driver, test);
	}
	public ViewLeadPage verifyFirstName(String data){
		verifyTextById("viewLead_firstName_sp", data);
		return this;
	}
	public ViewLeadPage verifyCompanyName(String data){
		verifyTextById("viewLead_companyName_sp", data);
		return this;
	}
	
	public ViewLeadPage verifyDuplicateLeadName()
	{
		//System.out.println(captureText);
		verifyTextById("viewLead_firstName_sp", captureText);
		return this;
	}
	
	
	public DuplicateLeadPage clickDuplicateButton()
	{
		clickByXpath("//a[@class='subMenuButton' and text()='Duplicate Lead']");
		return new DuplicateLeadPage(driver, test);
	}
	public MyLeadsPage clickDeleteButton()
	{
		clickByLink("Delete");
		return new MyLeadsPage(driver, test);
	}
	
	public FindLeadsPage clickFindLeadspage()
	{
		clickByLink("Find Leads");
		return new FindLeadsPage(driver, test);
	}
	
}










