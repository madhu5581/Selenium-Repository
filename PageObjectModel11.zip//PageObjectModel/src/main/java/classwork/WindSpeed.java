package classwork;

public class WindSpeed {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String givenText="Highest wind speed is 3kph and lowest wind speed is 1kph";
		String[] data=givenText.split("kph");
		//System.out.println(data[0]+"#$%"+data[1]);
		char speed1,speed2;
		int avgSpeed;
		speed1=data[0].charAt(data[0].length()-1);
		speed2=data[1].charAt(data[1].length()-1);
		//System.out.println(speed1+" "+speed2);

	

	int sum=Character.getNumericValue(speed1)+Character.getNumericValue(speed2);
	avgSpeed=sum/2;
	System.out.println(avgSpeed);
}
}
