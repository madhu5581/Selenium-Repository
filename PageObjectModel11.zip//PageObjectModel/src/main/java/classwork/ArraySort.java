package classwork;

import java.util.Arrays;

public class ArraySort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] name={"Rajan", "Sridhar","Madhu"};
		
		Arrays.sort(name);
/*		for(int i=0;i<=name.length-1;i++)
			System.out.println(name[i]);
*/		

       System.out.println(Arrays.toString(name));
	}

}
