package classwork;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

public class CountChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str="amazon";
		Integer keyValue=1;
		char[] chrArray=str.toCharArray();
		Map<Character,Integer> charCnt=new TreeMap<Character,Integer>();
		for(int i=0;i<=chrArray.length-1;i++)
		   if(!charCnt.containsKey(chrArray[i]))
			charCnt.put(chrArray[i],keyValue);
		   else
			//   System.out.println(charCnt.get(chrArray[i]));
			charCnt.put(chrArray[i],charCnt.get(chrArray[i])+1);
		
		for (Entry<Character,Integer> entry : charCnt.entrySet()) {
			System.out.println(entry.getKey()+"-->"+entry.getValue());
			
		}
			
		
		
	}

}
