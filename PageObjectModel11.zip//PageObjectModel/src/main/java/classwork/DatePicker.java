package classwork;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class DatePicker {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();	
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("https://jqueryui.com/datepicker/");
		driver.manage().window().maximize();
		WebElement we=driver.findElementByClassName("demo-frame");
		driver.switchTo().frame(we);
		WebElement dpTextBox=driver.findElementById("datepicker");
		Actions builder = new Actions(driver);
		builder.click(dpTextBox).perform();
		WebElement dateTable=driver.findElementByClassName("ui-datepicker-calendar");
		List <WebElement> rows=dateTable.findElements(By.tagName("tr"));
		int rowCount=rows.size();
		//System.out.println(rowCount);
		WebElement lastRow=rows.get(rowCount-1);
		List<WebElement> cells=lastRow.findElements(By.xpath("//tr/td/a"));
		int cellCount=cells.size();
		WebElement lastCell=cells.get(cellCount-1);
		builder.click(lastCell).build().perform();
		
		/*or we can use below code
		 * 
		 * List <WebElement> cells=driver.findElement
		 * 
		 * sByXPath("//tr/td/a");
		WebElement lastCell=cells.get(cells.size()-1);
		builder.click(lastCell).build().perform();*/
		
		

	}

}
