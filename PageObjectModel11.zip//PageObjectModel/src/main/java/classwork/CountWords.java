package classwork;

public class CountWords {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str="I m the Winner Today";
		String[] data=str.split(" ");
		System.out.println(data.length);
		

	}

}
