package classwork;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WeatherForeCast {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
	ChromeDriver driver = new ChromeDriver();	
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	driver.get("http://leaftaps.com:3000/");
	driver.manage().window().maximize();
    List<WebElement> day= driver.findElements(By.xpath("//div//span[@class='name']"));
    WebElement lastrow=day.get(day.size()-1);
    lastrow.click();
    List<WebElement> hrs=lastrow.findElements(By.xpath("//span/span[@class='hour']"));
    System.out.println(hrs.size());
    
	}

}
