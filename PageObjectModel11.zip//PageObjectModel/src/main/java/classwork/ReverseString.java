package classwork;

public class ReverseString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str="Wow! it is fun to do this.";
		int charCount=str.length();
		for(int i=charCount-1;i>=0;i--)
		{
			System.out.print(str.charAt(i));
			
		}
	}

}
