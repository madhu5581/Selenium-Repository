package classwork;

public class NumOfOccurrences {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="I m the Smart Learner";
		int occurences=0;
		for(int i=0;i<=str.length()-1;i++)
		{
			if(str.charAt(i)=='e')
			 occurences++;
		}

		System.out.println(occurences);
	}

}
