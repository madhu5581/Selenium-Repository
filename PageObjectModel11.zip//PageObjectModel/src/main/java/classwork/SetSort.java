package classwork;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class SetSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Set<String> name=new TreeSet<String>();
		name.add("NESA");
		name.add("babu");
		name.add("BALA");
		name.add("gopi");
		
		//List<String> listName=new ArrayList<>();
		//listName.addAll(name);
		//Collections.sort(listName);
		/*for (String eachListName : listName) {
			System.out.println(eachListName);
			
		}*/
		System.out.println(name);
		

	}

}
