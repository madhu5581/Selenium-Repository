package classwork;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class DragtoPixels {

	public static void main(String[] args) {
				
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();	
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("https://jqueryui.com/datepicker/");
		driver.manage().window().maximize();
		WebElement we=driver.findElementByClassName("demo-frame");
		
		driver.switchTo().frame(we);
		WebElement draggable=driver.findElementById("draggable");
		Actions builder = new Actions(driver);
		System.out.println(driver.findElementById("draggable").getLocation());
		builder.clickAndHold(draggable).dragAndDropBy(draggable, 150, 200).build().perform();
		System.out.println(driver.findElementById("draggable").getLocation());
		
	}

}
