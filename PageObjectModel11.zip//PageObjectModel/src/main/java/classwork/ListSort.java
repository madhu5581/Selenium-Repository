package classwork;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.internal.runners.model.EachTestNotifier;

public class ListSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> name=new ArrayList<String>();
		name.add("GOPI");
		name.add("Nesa");
		name.add("BABU");
		name.add("bala");
		
		Collections.sort(name);
		for (String mentorName : name) {
			System.out.println(mentorName);
			
		}
	}

}
