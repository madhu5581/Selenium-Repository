package wrappers;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

public class GenericWrappers implements Wrappers{
	RemoteWebDriver driver;
	public int i=0;

	/**
	 * This method will launch the given browser and maximise the browser and set the
	 * wait for 30 seconds and load the url
	 * @author Babu - TestLeaf
	 * @param browser - The browser of the application to be launched
	 * @param url - The url with http or https
	 * @ 
	 * 
	 */
	public void invokeApp(String browser, String url) {		
		if (browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
			driver = new ChromeDriver();
		} else if (browser.equalsIgnoreCase("firefox")) 
		{
			
			System.setProperty("webdriver.gecko.driver", "./drivers/geckodriver.exe");
		    driver = new FirefoxDriver();
			
		}
		driver.manage().window().maximize();
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		System.out.println("The browser : "+browser+" is launched Successfully");	
		takeSnap();
	}

	/**
	 * This method will enter the value to the text field using id attribute to locate
	 * 
	 * @param idValue - id of the webelement
	 * @param data - The data to be sent to the webelement
	 * @author Madhu - TestLeaf
	 * @return 
	 * @throws IOException 
	 * @ 
	 */

	public void enterById(String idValue, String data) {		
		driver.findElementById(idValue).clear();
		driver.findElementById(idValue).sendKeys(data);
		System.out.println("The Value "+data+" has been entered successfully in : "+idValue+"");
		takeSnap();
	}

	public void enterByName(String nameValue, String data) {
		driver.findElementByName(nameValue).clear();
		driver.findElementByName(nameValue).sendKeys(data);
		takeSnap();

	}

	public void enterByXpath(String xpathValue, String data) 
	{
		driver.findElementByXPath(xpathValue).sendKeys(data);
		takeSnap();
				// TODO Auto-generated method stub

	}

	public boolean verifyTitle(String title)
	{
		boolean flg=false;
		if(driver.getTitle().equals(title))
		{
			System.out.println("Page title "+title+" has been verified");
			
			flg=true;	
		}
		takeSnap();
         return flg;
         
		// TODO Auto-generated method stub
		
	}

	public boolean verifyTextById(String id, String text){
		boolean status=false;

		if((driver.findElementById(id).getText()).contains(text)){
			System.out.println("The Given Text :"+text+" Matches");
			status= true;
			
			// TODO Auto-generated method stub

		}
		takeSnap();
		return status;

	}

	public void verifyTextByXpath(String xpath, String text)
	{
		if (driver.findElementByXPath(xpath).getText().contains(text))
			System.out.println("The Given Text :"+text+" Matches");
		takeSnap();
		// TODO Auto-generated method stub

	}

	public void verifyTextContainsByXpath(String xpath, String text) {

		if (driver.findElementByXPath(xpath).getText().contains(text)) {
			System.out.println("The Given Text :"+text+" Matches");
		} 
		takeSnap();
	}

	public void clickById(String id)
	{
		driver.findElementById(id).click();
		takeSnap();
		// TODO Auto-generated method stub

	}

	public void clickByClassName(String classVal) {

		driver.findElementByClassName(classVal).click();
		System.out.println("The Button "+classVal+" Clicked Successfully");
		takeSnap();

	}

	public void clickByName(String name) 
	{
		driver.findElementByName(name).click();
		takeSnap();
		// TODO Auto-generated method stub

	}

	public void clickByLink(String name)
	{
		driver.findElementByLinkText(name).click();
		System.out.println("The link "+name+" has been clicked");
		takeSnap();
		// TODO Auto-generated method stub

	}

	public void clickByLinkNoSnap(String name) 
	{
		// TODO Auto-generated method stub

	}

	public void clickByXpath(String xpathVal) 
	{
		driver.findElementByXPath(xpathVal).click();
		System.out.println("The Xpath" +xpathVal+ " has been clicked");
		takeSnap();
		// TODO Auto-generated method stub

	}

	public void clickByXpathNoSnap(String xpathVal)
	{
		// TODO Auto-generated method stub

	}

	public String getTextById(String idVal) 
	{
		// TODO Auto-generated method stub
		return null;
	}

	public String getTextByXpath(String xpathVal) 
	{
		String getName=driver.findElementByXPath(xpathVal).getText();
		// TODO Auto-generated method stub
		takeSnap();
		return getName;
	}

	public void selectVisibileTextById(String id, String value)
	{
		Select options=new Select(driver.findElementById(id));
		options.selectByVisibleText(value);
		System.out.println("The value"+ value+" has been selected from dropdown");
		takeSnap();
		// TODO Auto-generated method stub

	}

	public void selectIndexById(String id, int value)
	{
		WebElement we=driver.findElementById(id);
		Select options=new Select(we);
		options.selectByIndex(value);
		takeSnap();
		// TODO Auto-generated method stub

	}

	public void switchToParentWindow() 
	{
	  	
	 	// TODO Auto-generated method stub

	}

	public void switchToLastWindow() 
	{
		// TODO Auto-generated method stub

	}

	public void acceptAlert() 
	{
		takeSnap();
		driver.switchTo().alert().dismiss();
		takeSnap();
		// TODO Auto-generated method stub

	}

	public void dismissAlert() 
	{
		takeSnap();
		driver.switchTo().alert().dismiss();
		takeSnap();
		// TODO Auto-generated method stub

	}

	public String getAlertText()
	{
		
		String str=driver.switchTo().alert().getText();
		takeSnap();
		// TODO Auto-generated method stub
		
		return str;
	}

	public void takeSnap() 
	{
		File src=driver.getScreenshotAs(OutputType.FILE);
		
       File dest=new File("./Output/"+"img"+i+".jpg");	
        try {
			FileUtils.copyFile(src,dest);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       i++;
		// TODO Auto-generated method stub

	}

	public void closeBrowser()  
	{
		driver.close();
		// TODO Auto-generated method stub

	}

	public void closeAllBrowsers() {
		// TODO Auto-generated method stub

	}

}
